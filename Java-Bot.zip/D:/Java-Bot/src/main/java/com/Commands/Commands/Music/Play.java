package com.Commands.Commands.Music;

import com.Commands.Commands.LavaPlayer.PlayerManager;
import com.Commands.Database.SQLiteDataSource;
import com.Commands.ICommand;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Play implements ICommand {
    @Override
    public String getName() {
        return "play";
    }

    @Override
    public String getDescription() {
        return "Joue un son (coût: 100 token)";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.STRING, "url", "L'URL de la musique a jouer", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        Integer tokenCount = 0;
        try {
            Connection connection = SQLiteDataSource.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT token FROM player_token WHERE PlayerId =" + event.getMember().getId().toString();
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                tokenCount = resultSet.getInt(1);
            }

            if (tokenCount >= 100 || event.getMember().hasPermission(Permission.ADMINISTRATOR)){
                Member member = event.getMember();
                GuildVoiceState memberVoiceState = member.getVoiceState();

                if(!memberVoiceState.inAudioChannel()) {
                    event.reply("Vous devez être dans un salon vocal").setEphemeral(true).queue();
                    return;
                }

                Member self = event.getGuild().getSelfMember();
                GuildVoiceState selfVoiceState = self.getVoiceState();

                if(!selfVoiceState.inAudioChannel()) {
                    event.getGuild().getAudioManager().openAudioConnection(memberVoiceState.getChannel());
                } else {
                    if(selfVoiceState.getChannel() != memberVoiceState.getChannel()) {
                        event.reply("Vous devez être dans le même salon vocal que moi").setEphemeral(true).queue();
                        return;
                    }
                }

                String name = event.getOption("url").getAsString();
                try {
                    new URI(name);
                } catch (URISyntaxException e) {
                    name = "ytsearch:" + name;
                }

                PlayerManager playerManager = PlayerManager.get();
                event.reply("Le son va être jouer").setEphemeral(true).queue();
                playerManager.play(event.getGuild(), name);

                if(!event.getMember().hasPermission(Permission.ADMINISTRATOR)) {
                    tokenCount -= 100;
                    query = "UPDATE player_token SET token = " + tokenCount.toString() + " WHERE PlayerId = " + event.getMember().getId().toString();
                    statement.execute(query);
                }

            } else {
                event.reply("Vous n'avez pas assez de jetons").setEphemeral(true).queue();
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}