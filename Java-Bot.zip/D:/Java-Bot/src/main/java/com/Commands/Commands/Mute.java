package com.Commands.Commands;

import com.Commands.ICommand;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.TimeUnit;

public class Mute implements ICommand{

    @Override
    public String getName() {
        return "mute";
    }

    @Override
    public String getDescription() {
        return "Mute un membre";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.USER, "membre", "Le membre a mute", true));
        options.add(new OptionData(OptionType.INTEGER, "durée", "La durée du mute (en minutes)", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event){
        if (event.getMember().hasPermission(Permission.ADMINISTRATOR)){
            Member muted = event.getOption("membre", OptionMapping::getAsMember);
            Integer duration = event.getOption("durée", OptionMapping::getAsInt);
            muted.timeoutFor(duration, TimeUnit.MINUTES).queue();
            event.reply(muted.getAsMention() + " a bien été mute").setEphemeral(true).queue();
        } else {
            event.reply("Vous n'avez pas la permission d'effectuer cette commande.").queue();
        }
    }
}
