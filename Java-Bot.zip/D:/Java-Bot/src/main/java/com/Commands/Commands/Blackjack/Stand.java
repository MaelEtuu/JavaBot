package com.Commands.Commands.Blackjack;

import com.Commands.Database.SQLiteDataSource;
import com.Commands.ICommand;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Stand implements ICommand {
    @Override
    public String getName() {
        return "stand";
    }

    @Override
    public String getDescription() {
        return "Vous permet de rester";
    }

    @Override
    public List<OptionData> getOptions() {
        return null;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if (event.getChannel().asTextChannel().getId().equals("1109450171995148309")){
            if (Join.game.getMember().getId() != event.getMember().getId()) {
                if (Join.game.finishGame(event.getChannel().asTextChannel())){
                    event.reply("Vous avez gagné!").queue();
                    try {
                        Connection connection = SQLiteDataSource.getConnection();
                        Statement statement = connection.createStatement();

                        String query = "SELECT token FROM player_token WHERE PlayerId =" + event.getMember().getId().toString();
                        Integer tokenPlayer = statement.executeQuery(query).getInt(1);
                        Integer token = tokenPlayer + Join.game.getMise();
                        query = "UPDATE player_token SET token = " + token.toString() + " WHERE PlayerId = " + event.getMember().getId().toString();
                        statement.execute(query);

                        statement.close();
                        connection.close();
                    } catch (SQLException e){
                        e.printStackTrace();
                    }
                } else {
                    event.reply("Le croupier a gagné avec " + Join.game.totalPointsDealer() + " points.").queue();
                }
                Join.game.Reset();
            } else {
                event.reply("Vous n'êtes pas dans la partie").setEphemeral(true).queue();
            }
        } else {
            event.reply("Vous n'êtes pas dans le bon channel").setEphemeral(true).queue();
        }
    }
}
