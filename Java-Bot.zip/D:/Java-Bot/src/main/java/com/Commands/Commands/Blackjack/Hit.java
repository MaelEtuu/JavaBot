package com.Commands.Commands.Blackjack;

import com.Commands.ICommand;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.List;

public class Hit implements ICommand {
    @Override
    public String getName() {
        return "hit";
    }

    @Override
    public String getDescription() {
        return "Vous donne une carte";
    }

    @Override
    public List<OptionData> getOptions() {
        return null;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if (event.getChannel().asTextChannel().getId().equals("1109450171995148309")){
            if (Join.game.getMember().getId() != event.getMember().getId()) {
                Join.game.addHandsPlayer();

                event.reply("Vos cartes : ").queue();
                List<Cards> hand = Join.game.getHandsPlayer();
                for (Cards card : hand) {
                    event.getChannel().asTextChannel().sendMessage("`" + card.value + " de " + card.color + "`").queue();
                }
                if (Join.game.totalPointsPlayer() > 21) {
                    event.getChannel().asTextChannel().sendMessage("Vous avez " + Join.game.totalPointsPlayer().toString() + " points. Vous avez perdu.").queue();
                    Join.game.Reset();
                } else {
                    event.getChannel().asTextChannel().sendMessage("Vous avez " + Join.game.totalPointsPlayer().toString() + " points.").queue();
                }
            } else {
                event.reply("Vous n'êtes pas dans la partie").setEphemeral(true).queue();
            }
        } else {
            event.reply("Vous n'êtes pas dans le bon channel").setEphemeral(true).queue();
        }
    }
}
