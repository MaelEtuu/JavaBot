package com.Commands.Commands.Blackjack;

import java.util.List;

public class Cards {
    public String color;
    public String value;

    public Cards(String color, String value) {
        this.color = color;
        this.value = value;
    }
}
