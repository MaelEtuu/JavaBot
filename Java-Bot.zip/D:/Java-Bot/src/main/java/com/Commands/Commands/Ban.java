package com.Commands.Commands;

import com.Commands.ICommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.TimeUnit;

public class Ban implements ICommand{

    @Override
    public String getName() {
        return "ban";
    }

    @Override
    public String getDescription() {
        return "Bannir un membre";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.USER, "bannis", "Le membre a bannir", true));
        options.add(new OptionData(OptionType.STRING, "raison", "La raison du bannissement", false));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        Member member = event.getMember();
        if(member.hasPermission(Permission.BAN_MEMBERS)) {
            Member banned = event.getOption("bannis", OptionMapping::getAsMember);
            OptionMapping reason = event.getOption("raison");

            Guild guild = member.getGuild();
            TextChannel channel = guild.getTextChannelById("1105783582498226178");
            if(reason == null) {
                guild.ban(banned, 0, TimeUnit.DAYS).reason(reason.getAsString()).queue();
                event.reply("Vous avez bannis " + banned.getAsMention()).setEphemeral(true).queue();
                channel.sendMessage(member.getAsMention() + " a bannis " + banned.getAsMention()).queue();
            } else {
                guild.ban(banned, 0, TimeUnit.DAYS).queue(
                        s->event.reply(member.getAsMention() + "Vous avez bannis " + banned.getAsMention() + "pour la raison : " + reason.getAsString()).setEphemeral(true).queue()
                );

                channel.sendMessage(member.getAsMention() + " a bannis " + banned.getAsMention() + "pour la raison : " + reason.getAsString()).queue();
            }
            TextChannel channel_ban = event.getGuild().getTextChannelById(1105783582498226178l);
            EmbedBuilder embedBuilder = new EmbedBuilder();
            embedBuilder.setTitle("Bannissement");
            embedBuilder.setDescription("**Modo:** `" + event.getMember().getUser() + "`");
            embedBuilder.appendDescription("\n**Bannis:** `" + banned.getAsMention() + "`");
            embedBuilder.appendDescription("\n**Date:** `" + LocalDateTime.now().toLocalDate().toString() + "`");
            embedBuilder.appendDescription("\n**Heure:** `" + LocalDateTime.now().toLocalTime().toString() + "`");
            channel_ban.sendMessageEmbeds(embedBuilder.build()).queue();
        } else {
            event.reply("Vous n'avez pas la permission d'effectuer cette commande.").queue();
        }
    }
}
