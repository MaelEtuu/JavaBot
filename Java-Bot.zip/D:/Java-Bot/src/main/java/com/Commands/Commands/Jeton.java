package com.Commands.Commands;

import com.Commands.Database.SQLiteDataSource;
import com.Commands.ICommand;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Jeton implements ICommand {
    @Override
    public String getName() {
        return "jetons";
    }

    @Override
    public String getDescription() {
        return "Vous donne votre nombre de jetons";
    }

    @Override
    public List<OptionData> getOptions() {
        return null;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        try {
            Connection connection = SQLiteDataSource.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT token FROM player_token WHERE PlayerId =" + event.getMember().getId().toString();
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                Integer tokenCount = resultSet.getInt(1);
                event.reply("Vous avez " + tokenCount.toString() + " jetons.").setEphemeral(true).queue();
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
