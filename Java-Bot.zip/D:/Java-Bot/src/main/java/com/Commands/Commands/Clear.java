package com.Commands.Commands;

import com.Commands.ICommand;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Clear implements ICommand{
    @Override
    public String getName() {
        return "clear";
    }

    @Override
    public String getDescription() {
        return "Supprime les messages du channel";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.STRING, "nombre", "Le nombre de message a supprimer", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event){
        if (event.getMember().hasPermission(Permission.ADMINISTRATOR)){
            Integer number = event.getOption("nombre", OptionMapping::getAsInt);
            TextChannel channel = event.getChannel().asTextChannel();

            if(number == null){
                event.reply("Usage: /clear <nombre>").setEphemeral(true).queue();
                return;
            }

            List<Message> messageList = channel.getHistory().retrievePast(number + 1).complete();
            channel.deleteMessages(messageList).queue();
            event.reply(number + " messages ont bien été supprimé.").setEphemeral(true).queue();
            TextChannel channel_clear = event.getGuild().getTextChannelById(1105794946914586654l);
            EmbedBuilder embedBuilder = new EmbedBuilder();
            embedBuilder.setTitle("Clear");
            embedBuilder.setDescription("**Modo:** `" + event.getMember().getUser() + "`");
            embedBuilder.appendDescription("\n**Channel:** `" + event.getChannel().getName() + "`");
            embedBuilder.appendDescription("\n**Nombre:** `" + number + "`");
            embedBuilder.appendDescription("\n**Date:** `" + LocalDateTime.now().toLocalDate().toString() + "`");
            embedBuilder.appendDescription("\n**Heure:** `" + LocalDateTime.now().toLocalTime().toString() + "`");
            channel_clear.sendMessageEmbeds(embedBuilder.build()).queue();
        } else {
            event.reply("Vous n'avez pas la permission d'effectuer cette commande.").queue();
        }
    }
}
