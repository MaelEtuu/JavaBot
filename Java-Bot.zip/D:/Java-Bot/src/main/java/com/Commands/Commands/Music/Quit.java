package com.Commands.Commands.Music;

import com.Commands.ICommand;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.List;

public class Quit implements ICommand {
    @Override
    public String getName() {
        return "quit";
    }

    @Override
    public String getDescription() {
        return "Fait quitter le channel vocal au bot discord";
    }

    @Override
    public List<OptionData> getOptions() {
        return null;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if(event.getMember().hasPermission(Permission.ADMINISTRATOR)){
            Member member = event.getMember();
            GuildVoiceState memberVoiceState = member.getVoiceState();

            if(!memberVoiceState.inAudioChannel()) {
                event.reply("Vous devez être dans un salon vocal").setEphemeral(true).queue();
                return;
            }

            Member self = event.getGuild().getSelfMember();
            GuildVoiceState selfVoiceState = self.getVoiceState();

            if(!selfVoiceState.inAudioChannel()) {
                event.getGuild().getAudioManager().openAudioConnection(memberVoiceState.getChannel());
            } else {
                if(selfVoiceState.getChannel() != memberVoiceState.getChannel()) {
                    event.reply("Vous devez être dans le même salon vocal que moi").setEphemeral(true).queue();
                    return;
                }
            }
            event.getGuild().getAudioManager().closeAudioConnection();
        }
    }
}
