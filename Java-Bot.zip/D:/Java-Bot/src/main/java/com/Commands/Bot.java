package com.Commands;

import com.Commands.Commands.*;
import com.Commands.Commands.Blackjack.*;
import com.Commands.Commands.Music.*;
import com.Commands.Database.SQLiteDataSource;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Bot extends ListenerAdapter {

    public static void main(String[] args) {
        CommandManager manager = new CommandManager();
        manager.add(new Ban());
        manager.add(new Clear());
        manager.add(new Mute());
        manager.add(new Staff());
        manager.add(new UnStaff());

        manager.add(new Play());
        manager.add(new Queue());
        manager.add(new NowPlaying());
        manager.add(new Repeat());
        manager.add(new Stop());
        manager.add(new Quit());

        manager.add(new Jeton());
        manager.add(new SetToken());

        manager.add(new NickName());

        manager.add(new Join());
        manager.add(new Hit());
        manager.add(new Stand());

        final String TOKEN = "MTEwNTI0ODU2ODUwNTI4MjU4MA.GmPk_m.326nbwNfAF_pMDVwShV4tccfzG70UEPYbFnVc4";
        JDABuilder jdaBuilder = JDABuilder.createDefault(TOKEN);
        jdaBuilder
                .enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.DIRECT_MESSAGES, GatewayIntent.GUILD_MEMBERS)
                .enableIntents(GatewayIntent.GUILD_VOICE_STATES)
                .enableIntents(GatewayIntent.MESSAGE_CONTENT)
                .addEventListeners(new Bot())
                .addEventListeners(manager)
                .build();
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event){
        Integer token = 0;
        try {
            Connection connection = SQLiteDataSource.getConnection();
            Statement statement = connection.createStatement();
            String query = "SELECT token FROM player_token WHERE PlayerId =" + event.getMember().getId().toString();
            ResultSet resultSet = statement.executeQuery(query);

            if (resultSet.next()) {
                Integer tokenCount = resultSet.getInt(1);
                token = tokenCount + 5;
            }
            query = "UPDATE player_token SET token = " + token.toString() + " WHERE PlayerId = " + event.getMember().getId().toString();
            statement.execute(query);

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onGuildMemberJoin(GuildMemberJoinEvent event) {
        try {
            Connection connection = SQLiteDataSource.getConnection();
            Statement statement = connection.createStatement();
            String query = "INSERT INTO player_token VALUES(" + event.getMember().getId().toString() + ", 200)";
            statement.execute(query);

            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}