package com.Commands.Commands;

import com.Commands.ICommand;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.ArrayList;
import java.util.List;

public class UnStaff implements ICommand {
    @Override
    public String getName() {
        return "unstaff";
    }

    @Override
    public String getDescription() {
        return "Retire un rôle a un membre";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.USER, "membre", "Le membre", true));
        options.add(new OptionData(OptionType.ROLE, "rôle", "Le rôle a retiré", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if (event.getMember().hasPermission(Permission.ADMINISTRATOR)){
            Member member = event.getOption("membre", OptionMapping::getAsMember);
            Guild guild = event.getGuild();
            Role role = event.getOption("rôle", OptionMapping::getAsRole);
            guild.removeRoleFromMember(member, role).queue();
            event.reply("Rôle retiré").setEphemeral(true).queue();
        } else {
            event.reply("Vous n'avez pas la permission d'effectuer cette commande.").queue();
        }
    }
}
