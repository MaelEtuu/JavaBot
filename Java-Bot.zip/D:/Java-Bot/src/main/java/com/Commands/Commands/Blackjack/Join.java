package com.Commands.Commands.Blackjack;

import com.Commands.Database.SQLiteDataSource;
import com.Commands.ICommand;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import javax.swing.plaf.nimbus.State;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Join implements ICommand {
    public static Game game = new Game();

    @Override
    public String getName() {
        return "join";
    }

    @Override
    public String getDescription() {
        return "Permet de rejoindre le jeu";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.INTEGER, "mise", "La mise que vous voulez mettre", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if (event.getChannel().asTextChannel().getId().equals("1109450171995148309")){
            if (game.getMember() == null) {
                try {
                    Connection connection = SQLiteDataSource.getConnection();
                    Statement statement = connection.createStatement();

                    game.setMember(event.getMember());
                    game.setMise(event.getOption("mise").getAsInt());
                    event.reply("Bonjour, vous venez d'entré dans le jeu veuillez ne pas quitter le channel tant que nous n'avons pas fini.").queue();
                    TextChannel channel = event.getChannel().asTextChannel();

                    String query = "SELECT token FROM player_token WHERE PlayerId =" + event.getMember().getId().toString();
                    Integer tokenPlayer = statement.executeQuery(query).getInt(1);
                    Integer token = tokenPlayer - event.getOption("mise").getAsInt();
                    query = "UPDATE player_token SET token = " + token.toString() + " WHERE PlayerId = " + event.getMember().getId().toString();
                    statement.execute(query);

                    game.addHandsPlayer();
                    channel.sendMessage("Vos cartes :").queue();
                    channel.sendMessage("`" + game.getHandsPlayer().get(0).value + " de " + game.getHandsPlayer().get(0).color + "`").queue();

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                event.reply("Un membre joue déjà.").setEphemeral(true).queue();
            }
        } else {
            event.reply("Vous n'êtes pas dans le bon channel").setEphemeral(true).queue();
        }
    }
}
