package com.Commands.Commands;

import com.Commands.Database.SQLiteDataSource;
import com.Commands.ICommand;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SetToken implements ICommand {
    @Override
    public String getName() {
        return "settoken";
    }

    @Override
    public String getDescription() {
        return "Met a jours les token d'un membre";
    }

    @Override
    public List<OptionData> getOptions() {
        List<OptionData> options = new ArrayList<>();
        options.add(new OptionData(OptionType.USER, "membre", "Le membre a qui ajouter/retirer des token", true));
        options.add(new OptionData(OptionType.INTEGER, "nombre", "Le nombre de token", true));
        return options;
    }

    @Override
    public void execute(SlashCommandInteractionEvent event) {
        if(event.getMember().hasPermission(Permission.ADMINISTRATOR)){
            try{
                Connection connection = SQLiteDataSource.getConnection();
                Statement statement = connection.createStatement();
                String query = "UPDATE player_token SET token = " + event.getOption("nombre").getAsString() + " WHERE PlayerId = " + event.getOption("membre").getAsMember().getId().toString();
                statement.execute(query);
                event.reply("Les token de " + event.getOption("membre").getAsMember().getAsMention() + " ont bien été mis a jours.").setEphemeral(true).queue();

                statement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            event.reply("Vous n'avez pas la permission d'effectuer cette commande.").queue();
        }
    }
}
