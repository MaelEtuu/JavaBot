package com.Commands.Commands.Blackjack;

import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Game {
    public List<Cards> game = new ArrayList<>();
    public Member member;
    public Integer mise = 0;
    List<Cards> hands_player = new ArrayList<>();
    List<Cards> hands_dealer = new ArrayList<>();

    public Game() {
        List<String> colors = new ArrayList<>(Arrays.asList("Coeur", "Carreau", "Trèfle", "Pique"));
        List<String> values = new ArrayList<>(Arrays.asList("2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Dame", "Roi", "As"));

        for(int i = 0; i < 3; i++){
            for (String color: colors) {
                for (String value: values) {
                    this.game.add(new Cards(color, value));
                }
            }
        }
        Collections.shuffle(this.game);
    }

    public Cards getCard(){
        Cards card = this.game.get(0);
        this.game.remove(0);
        return card;
    }

    public void addHandsPlayer(){
        this.hands_player.add(this.getCard());
    }

    public List<Cards> getHandsPlayer(){
        return this.hands_player;
    }

    public Integer totalPointsPlayer(){
        Integer point = 0;
        for (Cards card: hands_player) {
            if (Character.isDigit(card.value.charAt(0))){
                point += Integer.parseInt(card.value);
            } else if (card.value == "Valet" || card.value == "Dame" || card.value == "Roi"){
                point += 10;
            } else{
                point += 1;
            }
        }
        return point;
    }

    public Integer totalPointsDealer(){
        Integer point = 0;
        for (Cards card: hands_dealer) {
            if (Character.isDigit(card.value.charAt(0))){
                point += Integer.parseInt(card.value);
            } else if (card.value == "Valet" || card.value == "Dame" || card.value == "Roi"){
                point += 10;
            } else{
                point += 1;
            }
        }
        return point;
    }

    public boolean finishGame(TextChannel channel){
        hands_dealer.add(getCard());
        while (totalPointsDealer() < 21){
            hands_dealer.add(getCard());
            channel.sendMessage("Le dealer a tiré : " + hands_dealer.get(hands_dealer.size()-1).value + " de " + hands_dealer.get(hands_dealer.size()-1).color).queue();
            if (totalPointsDealer() > totalPointsPlayer() && totalPointsDealer() <= 21){
                channel.sendMessage("Le dealer a " + totalPointsDealer().toString() + " points.").queue();
                return false;
            }
        }
        return true;
    }

    public void Reset(){
        List<String> colors = new ArrayList<>(Arrays.asList("Coeur", "Carreau", "Trèfle", "Pique"));
        List<String> values = new ArrayList<>(Arrays.asList("2", "3", "4", "5", "6", "7", "8", "9", "10", "Valet", "Dame", "Roi", "As"));

        for(int i = 0; i < 3; i++){
            for (String color: colors) {
                for (String value: values) {
                    this.game.add(new Cards(color, value));
                }
            }
        }
        Collections.shuffle(this.game);
        member = null;
        Integer mise = 0;
        hands_player.clear();
        hands_dealer.clear();
    }

    public Integer getMise(){
        return mise;
    }

    public Member getMember(){
        return member;
    }

    public void setMise(Integer mise){
        this.mise = mise;
    }

    public void setMember(Member member){
        this.member = member;
    }
}
